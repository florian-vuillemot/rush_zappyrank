import zappy
import queue
import log
import ai
# import ai

class Engine:
    def __init__(self, port, name, host, mode):
        self._zappy = zappy.Zappy(port, name, host)
        # self._stateMachine = ai.Manager()
        self._run = False
        self._error = None
        self._ai = ai.Manager(self)
        self._serverReply = ''
        self._aiReply = 'Look'
        self._freq = 100
        self._cmds = queue.Queue(0)
        self._manual = mode

    def _getServerReply(self):
        self._serverReply = self._zappy._net.receive()
        cmds = self._serverReply.split('\n')
        for i in cmds:
            if i != '': self._cmds.put(i)
        return self._serverReply

    def _init(self):
        self._zappy._net.connect() # Connect to the server

        self._getServerReply() # Welcome message
        log.Head(self._cmds.get()) # ===========

        log.Inform('Retrieving player infos...')
        log.Inform("Player team: " + self._zappy._team)
        if self._manual:
            log.Inform("Initial mode set to manual")

        self._zappy._net.send(self._zappy._team + '\n') # Init call
        self._getServerReply() # Get reply
        if self._cmds.qsize() < 2:
            self._getServerReply()

        reply = self._cmds.get()
        if (reply == "ko" or reply == "ok"):
            log.Fail("Cannot retrieve player infos :(", bold=True)
            exit(84)
        freq = reply
        reply = self._cmds.get()
        pos_t = reply.split()

        self._freq = int(freq)
        self._run = True

    def _start(self):
        while self._run and not self._error:
            self._lap()

        if self._error:
            log.Fail(self._error)

    def _stop(self):
        self._run = False
        return False
    
    def _die(self):
        log.Warn('Dayum, this is the end for me... :\'(')
        return self._stop()

    def _lap(self):

        if self._manual:
            self._think()
            if not self._parseBasicActions(): return -1
            self._zappy._net.send(self._aiReply + '\n')
            self._getServerReply()
            while not self._cmds.empty() > 0: self._compute(self._cmds.get())
        else:
            self._eai()

    def _eai(self):
        if not self._ai._run or not self._run: return False
        needFood = self._ai._need_food()
        if not needFood:
            self._ai._need_ressource()
            
        # self._ai._need_help()
        # self._ai._need_me()


    def _compute(self, reply):
        log.Log(reply, color='Green')

    def _think(self):
        try: self._aiReply = input(log.setTime('$> '))
        except: print();self._error = 'Bad input or EOF'
    
    def _parseBasicActions(self):
        if self._aiReply == '/bizo': return self._stop()
        elif self._aiReply == '': return False
        elif self._aiReply == '/switch': return self._switchMode()
        return True
    
    def _switchMode(self):
        self._manual = not self._manual
        return False