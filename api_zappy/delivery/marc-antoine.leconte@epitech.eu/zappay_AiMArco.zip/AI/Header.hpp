/*
** Header.hpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Wed Jun 21 11:48:48 2017 Marco
** Last update Thu Jun 29 17:06:35 2017 Marco
*/

#ifndef HEADER_HPP
#define HEADER_HPP

#include <unordered_map>
#include <arpa/inet.h>
#include <functional>
#include <unistd.h>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <cstdio>
#include <locale>
#include <string>
#include <vector>
#include <map>
#endif
