/*
** AiManager.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiManager
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Tue Jun 20 18:52:27 2017 Marco
** Last update Sat Jun 24 19:30:29 2017 Marco
*/

#include "AiManager.hpp"

bool            AiManager::sendCryptMsg(const std::string &data)
{
    // check
    if (data.c_str() == NULL)
        return (false);

    // init
    std::srand(SEED);
    std::string encrypted_data = "Broadcast " + data;

    //crypt
    for (unsigned int i = 10; i < data.size(); i++)
      {
        int crypto = std::rand() % 25;
        encrypted_data.at(i) = (encrypted_data.at(i) - 97 + crypto) % 25 + 97;
      }

    //debug
    std::cerr << encrypted_data << std::endl;

    //push
    this->_idea.push_back(encrypted_data);
    return (true);
}

struct Scream     AiManager::receivCryptMsg(const std::string &data)
{
    // init
    struct Scream ret;

    std::srand(SEED);
    std::string cyphered_data = data.c_str() + 11;

    // check
    if (data.c_str() == NULL)
        return (ret);

    //cypher
    for (unsigned int i = 0; i < data.size(); i++)
      {
        int cypher = std::rand();
        cypher = cypher % 25;
        cyphered_data.at(i) = cyphered_data.at(i) - cypher - 97;
        if (cyphered_data.at(i) < 0)
          cyphered_data.at(i) += 25;
        cyphered_data.at(i) += 97;
      }

    //debug
    std::cerr << cyphered_data << std::endl;

    //build ret value
    ret.coord.first = 0;
    ret.coord.second = 0;
    if (data.at(9) == '1' || data.at(9) == '2' || data.at(9) == '8')
      ret.coord.first = 1;
    else if (data.at(9) == '4' || data.at(9) == '5' || data.at(9) == '6')
      ret.coord.first = -1;
    if (data.at(9) == '2' || data.at(9) == '3' || data.at(9) == '4')
      ret.coord.second = 1;
    else if (data.at(9) == '6' || data.at(9) == '7' || data.at(9) == '8')
      ret.coord.second = -1;
    ret.msg = cyphered_data;
    return (ret);
}
