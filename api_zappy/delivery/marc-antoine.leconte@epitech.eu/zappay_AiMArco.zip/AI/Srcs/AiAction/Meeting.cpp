/*
** Move.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiAction
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Tue Jun 27 13:45:13 2017 Marco
** Last update Thu Jun 29 23:34:12 2017 Marco
*/

#include "AiManager.hpp"

bool          AiManager::goToPlayer(void)
{
  std::vector<std::string>  arg;
  int                       direction = 0;

  if (this->_level == 1 && this->_ressourceOk)
    {
      this->levelUp();
      this->_ressourceOk = false;
      return (true);
    }

  while (this->_message.size())
    {
      arg = split(this->_message.at(this->_message.size() - 1), ' ');
      if (arg.size() < 5)
        return (false);
      if (arg.at(2) == "TRYUP"
        && std::stoi(arg.at(3)) == this->_level
        && std::stoi(arg.at(4)) > this->_waitingTime)
        {
          std::cout << " == " << arg.at(1).substr(0, arg.size() - 1) << '\n';
          direction = std::stoi(arg.at(1).substr(0, arg.size() - 1));
          if (direction == 0)
            {
              if (playerOnMyPosition() > 1)
                std::cout << "COUPAING !!!!!!!" << '\n';
              this->_idea.push_back("Broadcast SUP " + std::to_string(this->_level) + " " + std::to_string(this->_waitingTime));
              this->_idea.push_back("Look");
              this->_idea.push_back("Inventory");
              this->_waitingTime = 0;
              return (true);
            }
          if (direction == 5)
            {
              this->_idea.push_back("Right");
              this->_idea.push_back("Right");
              this->_idea.push_back("Forward");
            }
          if (direction >= 2 && direction <= 4)
            {
              this->_idea.push_back("Left");
              this->_idea.push_back("Forward");
              this->_idea.push_back("Right");
            }
          if (direction >= 6 && direction <= 8)
            {
              this->_idea.push_back("Right");
              this->_idea.push_back("Forward");
              this->_idea.push_back("Left");
            }
          if (direction == 1)
            this->_idea.push_back("Forward");
          this->_idea.push_back("Look");
          this->_idea.push_back("Inventory");
          this->_message.erase(this->_message.begin());
          return (true);
        }
      else if (arg.at(2) == "SUP")
        {
          direction = std::stoi(arg.at(1).substr(0, arg.size() - 1));
          std::cout << "{{ Oh !! someone is trying helping me !!}}" << '\n';
          if (this->_ressourceOk)
            {
              this->prepareLevelUp();
              this->_idea.push_back("Broadcast GO " + std::to_string(this->_level) + " " + std::to_string(this->_waitingTime));
              this->levelUp();
              this->_message.clear();
              return (true);
            }
        }
      else if (arg.at(2) == "GO")
        {
          direction = std::stoi(arg.at(1).substr(0, arg.size() - 1));
          if (direction == 0)
            {
              this->_message.clear();
              this->_idea.push_back("Look");
              this->_idea.push_back("Inventory");
              return (true);
            }
        }
      this->_message.erase(this->_message.begin());
    }
  return (false);
}

bool          AiManager::waitForPlayer(void)
{
  size_t      nb = 0;

  if (this->_level == 1)
    return (false);
  if (this->_level >= 0)
    nb = 1;
  if (this->_level > 1)
    nb = 2;
  if (this->_level > 3)
    nb = 4;
  if (this->_level > 5)
    nb = 6;

  nb -= this->playerOnMyPosition();

  if (this->_waitingTime < 500)
    {
      this->_waitingTime += 1;
      this->_idea.push_back("Broadcast TRYUP " + std::to_string(this->_level) + " " + std::to_string(this->_waitingTime) + " " + std::to_string(nb));
      this->_idea.push_back("Look");
      this->_idea.push_back("Inventory");
    }
  else
    {
      this->_idea.push_back("Fork");
      this->_idea.push_back("Look");
      this->_idea.push_back("Inventory");
      this->_waitingTime = 0;
    }
  return (true);
}
