/*
** LevelUp.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiAction
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Sat Jun 24 15:58:29 2017 Marco
** Last update Thu Jun 29 15:34:10 2017 Marco
*/

#include "AiManager.hpp"

std::unordered_map<int, Ressource> condition({
  {2, Ressource(1, 1)},
  {3, Ressource(2, 1, 1, 1)},
  {4, Ressource(2, 2, 0, 1, 0, 2)},
  {5, Ressource(4, 1, 1, 2, 0, 1)},
  {6, Ressource(4, 1, 2, 1, 3)},
  {7, Ressource(6, 1, 2, 3, 0, 1)},
  {8, Ressource(6, 2, 2, 2, 2, 2, 1)},
  });

void          AiManager::findStone(void)
{
  if (this->_directionChecked[0] && this->_directionChecked[1] && this->_directionChecked[2] && this->_directionChecked[3])
    {
      this->_directionChecked[0] = this->_directionChecked[1] = this->_directionChecked[2] = this->_directionChecked[3] = false;
      if (this->_xRun > this->_sizeX)
        {
          this->_idea.push_back("Right");
          this->_idea.push_back("Forward");
          this->_idea.push_back("Right");
          this->_xRun = 0;
        }
      else
        this->_idea.push_back("Forward");
    }
  else
    {
      this->_directionChecked[this->_direction] = true;
      this->_idea.push_back("Right");
    }
}

bool          AiManager::takeStones(const Ressource &findMe)
{
  bool        token = false;

  if (this->_look.size() <= 0)
    return (false);

  if (lookToRessource(this->_look.at(0)).linemate > 0 && this->_inventory.linemate < findMe.linemate)
    {
      this->_idea.push_back("Take linemate");
      token = true;
    }
  if (lookToRessource(this->_look.at(0)).deraumere > 0 && this->_inventory.deraumere < findMe.deraumere)
    {
      this->_idea.push_back("Take deraumere");
      token = true;
    }
  if (lookToRessource(this->_look.at(0)).sibur > 0 && this->_inventory.sibur < findMe.sibur)
    {
      this->_idea.push_back("Take sibur");
      token = true;
    }
  if (lookToRessource(this->_look.at(0)).mendiane > 0 && this->_inventory.mendiane < findMe.mendiane)
    {
      this->_idea.push_back("Take mendiane");
      token = true;
    }
  if (lookToRessource(this->_look.at(0)).phiras > 0 && this->_inventory.phiras < findMe.phiras)
    {
      this->_idea.push_back("Take phiras");
      token = true;
    }
  if (lookToRessource(this->_look.at(0)).thystame > 0 && this->_inventory.thystame < findMe.thystame)
    {
      this->_idea.push_back("Take thystame");
      token = true;
    }
  this->_idea.push_back("Inventory");
  this->_idea.push_back("Look");
  return (token);
}

void          AiManager::getStone(const std::string &stone)
{
  int         look;

  if (this->_look.size() <= 0)
    return ;

  for (size_t i = 1; i < this->_look.size(); i++)
    {
      look = 0;
      if (stone == "linemate")
        look = lookToRessource(this->_look.at(i)).linemate;
      else if (stone == "deraumere")
        look = lookToRessource(this->_look.at(i)).deraumere;
      else if (stone == "sibur")
       look = lookToRessource(this->_look.at(i)).sibur;
      else if (stone == "mendiane")
        look = lookToRessource(this->_look.at(i)).mendiane;
      else if (stone == "phiras")
        look = lookToRessource(this->_look.at(i)).phiras;
      else if (stone == "thystame")
			  look = lookToRessource(this->_look.at(i)).thystame;

      if (look > 0)
        {
          if (i >= 1)
            this->_idea.push_back("Forward");
          if (i >= 4)
            this->_idea.push_back("Forward");
          if (i >= 9)
            this->_idea.push_back("Forward");
          if (i == 1 || i == 5 || i == 11 || i == 4 || i == 10 || i == 9)
            {
              this->_idea.push_back("Left");
              this->_idea.push_back("Forward");
            }
          if (i == 3 || i == 7 || i == 13 || i == 8 || i == 14 || i == 15)
            {
              this->_idea.push_back("Right");
              this->_idea.push_back("Forward");
            }
          this->_idea.push_back("Inventory");
          this->_idea.push_back("Look");
        }
    }
  this->findStone();
  this->_idea.push_back("Inventory");
  this->_idea.push_back("Look");
}

void          AiManager::searchStone(const Ressource &findMe)
{
  if (this->takeStones(findMe))
    return ;

  if (findMe.linemate > this->_inventory.linemate)
    this->getStone("linemate");
  else if (findMe.deraumere > this->_inventory.deraumere)
    this->getStone("deraumere");
  else if (findMe.sibur > this->_inventory.sibur)
    this->getStone("sibur");
  else if (findMe.mendiane > this->_inventory.mendiane)
    this->getStone("mendiane");
  else if (findMe.phiras > this->_inventory.phiras)
    this->getStone("phiras");
  else if (findMe.thystame > this->_inventory.thystame)
    this->getStone("thystame");
  this->_idea.push_back("Inventory");
  this->_idea.push_back("Look");
  return ;
}

bool          AiManager::tryLevelUp(void)
{
  if (this->_level >= 8)
    return (false);

  for (auto i = condition.begin(); i != condition.end(); i++)
    {
      if (this->_level + 1 == i->first)
        {
          if (i->second.linemate <= this->_inventory.linemate
            && i->second.deraumere <= this->_inventory.deraumere
            && i->second.sibur <= this->_inventory.sibur
            && i->second.mendiane <= this->_inventory.mendiane
            && i->second.phiras <= this->_inventory.phiras
            && i->second.thystame <= this->_inventory.thystame)
              this->_ressourceOk = true;
          else
            {
              this->searchStone(i->second);
              return (true);
            }
        }
    }
  return (false);
}

void          AiManager::prepareLevelUp(void)
{
  for (auto i = condition.begin(); i != condition.end(); i++)
    {
      if (this->_level + 1 == i->first)
        {
          for (size_t it = 0; it < lookToRessource(this->_look.at(0)).linemate; it++)
            this->_idea.push_back("Take linemate");
          for (size_t ita = 0; ita < lookToRessource(this->_look.at(0)).deraumere; ita++)
            this->_idea.push_back("Take deraumere");
          for (size_t itb = 0; itb < lookToRessource(this->_look.at(0)).sibur; itb++)
            this->_idea.push_back("Take sibur");
          for (size_t itc = 0; itc < lookToRessource(this->_look.at(0)).mendiane; itc++)
            this->_idea.push_back("Take mendiane");
          for (size_t itd = 0; itd < lookToRessource(this->_look.at(0)).phiras; itd++)
            this->_idea.push_back("Take phiras");
          for (size_t ite = 0; ite < lookToRessource(this->_look.at(0)).thystame; ite++)
            this->_idea.push_back("Take thystame");
          for (size_t it = 0; it < this->_inventory.linemate && it < i->second.linemate; it++)
            this->_idea.push_back("Set linemate");
          for (size_t ita = 0; ita < this->_inventory.deraumere && ita < i->second.deraumere; ita++)
            this->_idea.push_back("Set deraumere");
          for (size_t itb = 0; itb < this->_inventory.sibur && itb < i->second.sibur; itb++)
            this->_idea.push_back("Set sibur");
          for (size_t itc = 0; itc < this->_inventory.mendiane && itc < i->second.mendiane; itc++)
            this->_idea.push_back("Set mendiane");
          for (size_t itd = 0; itd < this->_inventory.phiras && itd < i->second.phiras; itd++)
            this->_idea.push_back("Set phiras");
          for (size_t ite = 0; ite < this->_inventory.thystame && ite < i->second.thystame; ite++)
            this->_idea.push_back("Set thystame");
          return ;
        }
    }
}

void          AiManager::levelUp(void)
{
  for (auto i = condition.begin(); i != condition.end(); i++)
    {
      if (this->_level + 1 == i->first && this->playerOnMyPosition() >= i->second.food)
        {
          if (this->playerOnMyPosition() == 1)
            this->prepareLevelUp();
          this->_idea.push_back("Incantation");
          this->_idea.push_back("Inventory");
          this->_idea.push_back("Look");
          this->_ressourceOk = false;
          this->_waitingTime = 0;
          return ;
        }
      else if (this->_level + 1 == i->first && this->playerOnMyPosition() < i->second.food)
        std::cout << "/////////////////////////\n/// NOT ENOUGH PLAYER ///\n///         " << this->playerOnMyPosition() <<  "         ///\n///         " << i->second.food <<  "         ///\n/////////////////////////" << '\n';
    }
  this->_idea.push_back("Look");
  this->_idea.push_back("Inventory");
}
