/*
** AiAction.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiAction
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Sat Jun 24 14:36:57 2017 Marco
** Last update Thu Jun 29 18:22:53 2017 Marco
*/

#include "AiManager.hpp"

void          AiManager::findFood(void)
{
  if (this->_directionChecked[0] && this->_directionChecked[1] && this->_directionChecked[2] && this->_directionChecked[3])
    {
      this->_directionChecked[0] = this->_directionChecked[1] = this->_directionChecked[2] = this->_directionChecked[3] = false;
      if (this->_xRun > this->_sizeX)
        {
          this->_idea.push_back("Right");
          this->_idea.push_back("Forward");
          this->_idea.push_back("Right");
          this->_xRun = 0;
        }
      else
        this->_idea.push_back("Forward");
    }
  else
    {
      this->_directionChecked[this->_direction] = true;
      this->_idea.push_back("Right");
    }
}

bool          AiManager::searchFood()
{
  if (this->_inventory.food > 20 && this->_waitingTime > 0)
    return (false);
  this->_waitingTime = 0;
  if (this->_inventory.food > 99 && this->_ressourceOk)
    return (false);
  this->_ressourceOk = false;
  if (this->_inventory.food > 199)
    return (false);
  this->_ressourceOk = false;
  if (this->_look.size() > 0 && lookToRessource(this->_look.at(0)).food > 0)
    {
      this->_idea.push_back("Take food");
      this->_idea.push_back("Look");
    }
  else if (this->_look.size() > 0)
    {
      for (size_t i = 1; i < this->_look.size(); i++)
        {
          if (lookToRessource(this->_look.at(i)).food > 0)
            {
              if (i >= 1)
                this->_idea.push_back("Forward");
              if (i >= 4)
                this->_idea.push_back("Forward");
              if (i >= 9)
                this->_idea.push_back("Forward");
              if (i == 1 || i == 5 || i == 11 || i == 4 || i == 10 || i == 9)
                {
                  this->_idea.push_back("Left");
                  this->_idea.push_back("Forward");
                }
              if (i == 3 || i == 7 || i == 13 || i == 8 || i == 14 || i == 15)
                {
                  this->_idea.push_back("Right");
                  this->_idea.push_back("Forward");
                }
              this->_idea.push_back("Inventory");
              this->_idea.push_back("Look");
              return (true);
            }
        }
      this->findFood();
    }
  this->_idea.push_back("Inventory");
  this->_idea.push_back("Look");
  return (true);
}
