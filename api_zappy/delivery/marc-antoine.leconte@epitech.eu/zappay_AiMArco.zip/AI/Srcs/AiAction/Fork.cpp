/*
** Fork.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiAction
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Thu Jun 29 16:37:14 2017 Marco
** Last update Thu Jun 29 22:44:13 2017 Marco
*/

#include "AiManager.hpp"

bool          AiManager::callFriend(void)
{
  std::vector<std::string>  tmp;
  int                       nbr = 0;

  writeIn(this->_fd, "Connect_nbr\n");
  while (tmp.size() <= 0)
    {
      tmp.clear();
      this->readIn(this->_fd, &tmp);
      if (tmp.at(0) == "ko")
        tmp.clear();
    }
  if (std::isdigit(tmp.at(0)[0]))
    nbr = std::stoi(tmp.at(0));
  if (nbr > 0)
    {
      if (!fork())
        {
          AiManager all(this->getAc(), this->getAv());

          if (!all.doConnect())
            exit(84);
          while (all.isRunning())
            {
              all.run();
              all.doSelect();
            }
          exit(84);
        }
      this->_idea.push_back("Look");
      this->_idea.push_back("Inventory");
      return (true);
    }
  return (false);
}
