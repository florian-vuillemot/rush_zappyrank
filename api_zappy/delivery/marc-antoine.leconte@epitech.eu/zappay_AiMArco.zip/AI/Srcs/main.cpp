/*
** main.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Tue Jun 20 18:41:53 2017 Marco
** Last update Wed Jun 21 16:31:02 2017 Marco
*/

#include "AiManager.hpp"

int         main(int ac, char **av)
{
  AiManager all(ac, av);

  if (!all.doConnect())
    return (0);
  while (all.isRunning())
    {
      all.run();
      all.doSelect();
    }
  return (0);
}
