/*
** utils.hpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Wed Jun 21 13:39:58 2017 Marco
** Last update Wed Jun 21 23:31:00 2017 Marco
*/

#ifndef UTILS_HPP
# define UTILS_HPP

#include "Header.hpp"

std::string               epur(const std::string &str);

template<typename Out>
void                      split_(const std::string &s, char delim, Out result, bool addEmpty = false);
std::vector<std::string>  split(const std::string &s, char delim, bool addEmpty = false);

#endif
