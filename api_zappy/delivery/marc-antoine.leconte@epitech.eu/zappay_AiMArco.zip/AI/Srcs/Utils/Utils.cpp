/*
** Utils.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/Utils
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Wed Jun 21 13:41:49 2017 Marco
** Last update Wed Jun 21 23:30:44 2017 Marco
*/

#include "Utils.hpp"

std::string       epur(const std::string &str)
{
  std::string     ret;
  int             i = 0;

  while (str[i] == ' ' || str[i] == '\r' || str[i] == '\n' || str[i] == '\t')
    i += 1;
  while (str[i])
    {
      if (str[i] == ' ' || str[i] == '\r' || str[i] == '\n' || str[i] == '\t')
        {
          while (str[i] == ' ' || str[i] == '\r' || str[i] == '\n' || str[i] == '\t')
            i += 1;
          if (!str[i])
            return (ret);
          ret += " ";
        }
      ret += str[i];
      i += 1;
    }
  return (ret);
}

template<typename Out>
void split_(const std::string &s, char delim, Out result, bool addEmpty)
{
  std::stringstream ss;
  ss.str(s);
  std::string item;
  while (std::getline(ss, item, delim))
    {
      if (item != "" || addEmpty)
        *(result++) = item;
    }
}

std::vector<std::string> split(const std::string &s, char delim, bool addEmpty)
{
  std::vector<std::string> elems;
  split_(s, delim, std::back_inserter(elems), addEmpty);
  return (elems);
}
