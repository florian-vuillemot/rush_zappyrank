/*
** AiManager.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiManager
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Tue Jun 20 18:52:27 2017 Marco
** Last update Thu Jun 29 17:08:22 2017 Marco
*/

#ifndef AI_MANAGER_HPP
# define AI_MANAGER_HPP

#include "Utils.hpp"

# define FRONT 0
# define RIGHT 1
# define BACK 2
# define LEFT 3

# define SEED 777

struct Scream
  {
    std::pair<int, int> coord;
    std::string         msg;
  };

struct Ressource
{
  size_t       food;
  size_t       linemate;
  size_t       deraumere;
  size_t       sibur;
  size_t       mendiane;
  size_t       phiras;
  size_t       thystame;

  explicit Ressource(int f = 0, int l = 0, int d = 0, int s = 0, int m = 0, int p = 0, int t = 0) :
    food(f),
    linemate(l),
    deraumere(d),
    sibur(s),
    mendiane(m),
    phiras(p),
    thystame(t) {}
};

class AiManager
  {
    private:
      int           _ac;
      char          **_av;

    private:
      std::string   _host;
      std::string   _team;
      int           _port;
      std::string   _ip;

    private:
      bool          _connected;
      int           _clientNum;
      int           _sizeX;
      int           _sizeY;

    private:
      struct sockaddr_in        _socket;
      int                       _fd;

    private:
      std::string               _mind;
      std::string               _goal;
      std::vector<std::string>  _idea;

    private:
      int                       _direction;
      int                       _x;
      int                       _y;

    private:
      std::string               _lastAction;
      size_t                    _teamSize;
      std::vector<std::string>  _look;
      int                       _waitingTime;

    private:
      Ressource                 _inventory;
      std::vector<std::string>  _buffer;
      bool                      _ressourceOk;

    private:
      std::vector<std::string>  _message;

    private:
      bool                      _directionChecked[4];
      int                       _xRun;
      int                       _yRun;

    private:
      int                       _level;

    private:
      bool                      _run;

    private:
      std::string   getArg(int, char **, int, std::string);
      void          findAndAttribute(int, char **, int);
      void          argumentParsing(int, char **);

    public:
      explicit      AiManager(int, char **);
      virtual       ~AiManager(void);

    public:
      void          readIn(int, std::vector<std::string> *);
      void          writeIn(int, std::string);

    public:
      bool          doConnect(void);
      bool          doSelect(void);
      bool          run(void);

    private:
      void          think(void);
      void          exec(void);

    private:
      bool          searchFood(void);
      void          findFood(void);

    private:
      bool          goToPlayer(void);
      bool          waitForPlayer(void);

    private:
      void          searchStone(const Ressource &);
      bool          takeStones(const Ressource &);
      void          getStone(const std::string &);
      void          prepareLevelUp(void);
      void          findStone(void);
      void          levelUp(void);

    private:
      struct Scream receivCryptMsg(const std::string &);
      bool          sendCryptMsg(const std::string &);

    private:
      bool          tryLevelUp(void);
      bool          callFriend(void);

    private:
      void          executeCommand(void);
      void          incantation(void);
      void          connectNbr(void);
      void          inventory(void);
      void          broadcast(void);
      void          forward(void);
      void          right(void);
      void          eject(void);
      void          left(void);
      void          look(void);
      void          take(void);
      void          set(void);

    private:
      void          interpretLookInMap(std::vector<std::string>);
      Ressource     lookToRessource(std::string) const;
      size_t        playerOnMyPosition(void) const;

    public:
      bool          isRunning(void) const;
      std::string   getHost(void) const;
      std::string   getTeam(void) const;
      int           getPort(void) const;
      char          **getAv(void) const;
      int           getAc(void) const;
  };

#endif
