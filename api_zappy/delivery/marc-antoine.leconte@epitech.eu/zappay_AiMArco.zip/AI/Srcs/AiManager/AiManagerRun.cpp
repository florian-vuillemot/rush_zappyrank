/*
** AiManagerRun.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiManager
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Wed Jun 21 16:40:26 2017 Marco
** Last update Thu Jun 29 18:42:28 2017 Marco
*/

#include "AiManager.hpp"

void          AiManager::think(void)
{
  std::map<std::string, std::function<bool()>> goal({
    {"EAT", [&] (){return (this->searchFood());}},
    {"FORK", [&] (){return (this->callFriend());}},
    {"GOTO", [&] (){return (this->goToPlayer());}},
    {"COLLECT", [&] (){return (this->tryLevelUp());}},
    {"WAIT", [&] (){return (this->waitForPlayer());}}
    });

  if (this->_idea.size() <= 0)
    {
      for (auto i = goal.begin(); i != goal.end(); i++)
        {
          if (i->second())
            {
              std::cout << i->first << '\n';
              return ;
            }
        }
      std::cout << "NOTHING" << '\n';
      this->_idea.push_back("Look");
      this->_idea.push_back("Inventory");
    }
}

void          AiManager::exec(void)
{
  this->_lastAction = "";
  if (this->_idea.size() > 0)
    {
      writeIn(this->_fd, this->_idea.at(0) + "\n");
      this->_lastAction = this->_idea.at(0);
      this->_idea.erase(this->_idea.begin());
      std::cout << "--------------------- GONNA DO: " << this->_lastAction << '\n';
    }
}

bool          AiManager::run(void)
{
  this->think();
  this->exec();
  return (true);
}
