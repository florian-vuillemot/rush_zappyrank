/*
** MapManip.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiManager
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Thu Jun 22 14:59:07 2017 Marco
** Last update Wed Jun 28 10:35:11 2017 Marco
*/

#include "AiManager.hpp"

Ressource     AiManager::lookToRessource(std::string str) const
{
  Ressource   back;
  std::vector<std::string>  buff;

  if (str == "")
    return (back);
  buff = split(str, ' ');

  for (size_t i = 0; i < buff.size(); i++)
    {
      if (buff.at(i) == "food")
        back.food += 1;
      if (buff.at(i) == "linemate")
        back.linemate += 1;
      if (buff.at(i) == "deraumere")
        back.deraumere += 1;
      if (buff.at(i) == "sibur")
        back.sibur += 1;
      if (buff.at(i) == "mendiane")
        back.mendiane += 1;
      if (buff.at(i) == "phiras")
        back.phiras += 1;
      if (buff.at(i) == "thystame")
        back.thystame += 1;
    }
  return (back);
}

size_t           AiManager::playerOnMyPosition(void) const
{
  std::vector<std::string>  buff;
  size_t                    back = 0;

  if (this->_look.size() <= 0)
    return (0);
  buff = split(this->_look.at(0), ' ');
  for (size_t i = 0; i < buff.size(); i++)
    {
      if (buff.at(i) == "player")
        back += 1;
    }
  return (back);
}

void          AiManager::interpretLookInMap(std::vector<std::string> look)
{
  for (size_t i = 0; i < look.size(); i++)
    lookToRessource(look.at(i));
}
