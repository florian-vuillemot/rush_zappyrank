/*
** UnderstandCommand.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiManager
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Wed Jun 21 17:58:01 2017 Marco
** Last update Thu Jun 29 22:50:10 2017 Marco
*/

#include "AiManager.hpp"

void          AiManager::executeCommand()
{
  std::unordered_map<std::string, std::function<void()>> actions({
    {"Forward", [&] (){return (this->forward());}},
    {"Right", [&] (){return (this->right());}},
    {"Left", [&] (){return (this->left());}},
    {"Look", [&] (){return (this->look());}},
    {"Inventory", [&] (){return (this->inventory());}},
    {"Broadcast", [&] (){return (this->broadcast());}},
    {"Connect_nbr", [&] (){return (this->connectNbr());}},
    {"Eject", [&] (){return (this->eject());}},
    {"Take", [&] (){return (this->take());}},
    {"Set", [&] (){return (this->set());}},
    {"Incantation", [&] (){return (this->incantation());}}
    });

while (this->_buffer.size())
  {
    if (std::strncmp("dead", this->_buffer.at(0).c_str(), 4) == 0)
      {
        std::cout << "PLAYER DIED !! GAME OVER !!" << '\n';
        this->_run = false;
        return ;
      }
    for (auto it = actions.begin(); it != actions.end(); it++)
      {
        if (std::strncmp(this->_lastAction.c_str(), it->first.c_str(), it->first.size()) == 0)
          it->second();
      }
    if (this->_buffer.size())
      this->_buffer.erase(this->_buffer.begin());
  }
}

void          AiManager::incantation(void)
{
  std::string level;

  //std::cout << "//--// Incantation" << std::endl;
  std::cout << " > " << this->_lastAction << " ";
  std::cout << " ||[--- " << this->_buffer.at(0) << " ---]||" << std::endl;

  while (this->_buffer.size() < 2)
    this->readIn(this->_fd, &this->_buffer);

  level = this->_buffer.at(1);
  std::cout << " " << level << '\n';
  if (this->_buffer.at(0) == "Elevation underway")
    {
      if (level != "ko")
        this->_level += 1;
      else
        this->_ressourceOk = false;
    }
  else
    this->_ressourceOk = false;
  this->_buffer.erase(this->_buffer.begin());
}

void          AiManager::connectNbr(void)
{
  std::cout << "//--// Connect Nbr" << std::endl;
}

void          AiManager::inventory(void)
{
  std::vector<std::string>  buff;
  std::string               one;
  int                       two;

  while (this->_buffer.size() <= 0 && this->_buffer.at(0).size() <= 0 && this->_buffer.at(0)[0] != '[')
    {
      if (this->_buffer.size())
        {
          std::cout << this->_buffer.at(0) << '\n';
          this->_buffer.erase(this->_buffer.begin());
        }
      this->readIn(this->_fd, &this->_buffer);
    }

  buff = split(this->_buffer.at(0), ',');
  for (size_t i = 0; i < buff.size(); i++)
    {
      if (buff.at(i)[0] == '[')
        buff.at(i) = buff.at(i).substr(1);
      if (buff.at(i)[buff.at(i).size() - 1] == ']')
        buff.at(i) = buff.at(i).substr(0, buff.at(i).size() - 2);
      buff.at(i) = epur(buff.at(i));
      if (buff.at(i).find(" ") != std::string::npos)
        {
          one = buff.at(i).substr(0, buff.at(i).find(" "));
          two = 0;
          if (buff.at(i).substr(buff.at(i).find(" ") + 1)[0] <= '9'
        && buff.at(i).substr(buff.at(i).find(" ") + 1)[0] >= '0')
            two = std::stoi(buff.at(i).substr(buff.at(i).find(" ") + 1));
          if (one == "food")
            this->_inventory.food = two;
          if (one == "linemate")
            this->_inventory.linemate = two;
          if (one == "deraumere")
            this->_inventory.deraumere = two;
          if (one == "sibur")
            this->_inventory.sibur = two;
          if (one == "mendiane")
            this->_inventory.mendiane = two;
          if (one == "phiras")
            this->_inventory.phiras = two;
          if (one == "thystame")
            this->_inventory.thystame = two;
        }
    }
/*  std::cout << "food = " << this->_inventory.food << '\n';
  std::cout << "linemate = " << this->_inventory.linemate << '\n';
  std::cout << "deraumere = " << this->_inventory.deraumere << '\n';
  std::cout << "sibur = " << this->_inventory.sibur << '\n';
  std::cout << "mendiane = " << this->_inventory.mendiane << '\n';
  std::cout << "phiras = " << this->_inventory.phiras << '\n';
  std::cout << "thystame = " << this->_inventory.thystame << '\n';*/
  //std::cout << "//--// Inventory" << std::endl;
  //std::cout << " " << this->_lastAction << " ";
}

void          AiManager::broadcast(void)
{
  //std::cout << "//--// Broadcast" << std::endl;
  std::cout << " " << this->_lastAction << " ";
  if (this->_buffer.at(0)[0] != '[')
    std::cout << this->_buffer.at(0) << '\n';
}

void          AiManager::forward(void)
{
  //std::cout << "//--// Forward" << std::endl;
}

void          AiManager::right(void)
{
  //std::cout << "//--// Right" << std::endl;
  if (this->_buffer.at(0) == "ok")
    this->_direction += 1;
  if (this->_direction >= 4)
    this->_direction = 0;
}

void          AiManager::eject(void)
{
  std::cout << "//--// Eject" << std::endl;
}

void          AiManager::left(void)
{
  //std::cout << "//--// Left" << std::endl;
  if (this->_buffer.at(0) == "ok")
    this->_direction -= 1;
  if (this->_direction < 0)
    this->_direction = 3;
  }

void          AiManager::look(void)
{
  std::vector<std::string>  buff;

  while (this->_buffer.size() <= 0 && this->_buffer.at(0).size() <= 0 && this->_buffer.at(0)[0] != '[')
    {
      if (this->_buffer.size())
        {
          std::cout << this->_buffer.at(0) << '\n';
          this->_buffer.erase(this->_buffer.begin());
        }
      this->readIn(this->_fd, &this->_buffer);
    }
  this->_look.clear();
  if (this->_buffer.size())
    buff = split(this->_buffer.at(0), ',', true);
  for (size_t i = 0; i < buff.size(); i++)
    {
      if (buff.at(i)[0] == '[')
        buff.at(i) = buff.at(i).substr(1);
      if (buff.at(i)[buff.at(i).size() - 1] == ']')
        buff.at(i) = buff.at(i).substr(0, buff.at(i).size() - 2);
      buff.at(i) = epur(buff.at(i));
    }
  if (buff.size())
    this->_look = buff;
  if (this->_look.size() > 4)
    this->_level = 1;
  if (this->_look.size() > 8)
    this->_level = 2;
  if (this->_look.size() > 15)
    this->_level = 3;
  if (this->_look.size() > 24)
    this->_level = 4;
  if (this->_look.size() > 35)
    this->_level = 5;
    //std::cout << "//--// Look" << std::endl;
  //std::cout << " " << this->_lastAction << " ";
}

void          AiManager::take(void)
{
  //std::cout << "//--// Take" << std::endl;
  //std::cout << " " << this->_lastAction << " ";
  //std::cout << this->_buffer.at(0) << '\n';
}

void          AiManager::set(void)
{
  //std::cout << "//--// Set" << std::endl;
  //std::cout << " " << this->_lastAction << " ";
  //std::cout << this->_buffer.at(0) << '\n';
}
