/*
** AiManager.cpp for PSU_2016_zappy in /home/marco/Bureau/rendu/PSU/PSU_2016_zappy/AI/Srcs/AiManager
**
** Made by Marco
** Login   <marco@epitech.net>
**
** Started on  Tue Jun 20 18:52:27 2017 Marco
** Last update Thu Jun 29 16:56:31 2017 Marco
*/

#include "AiManager.hpp"

////////////////////////////////
///________INITIALIZER_______///
////////////////////////////////

AiManager::AiManager(int ac, char **av):
  _ac(ac),
  _av(av),
  _host("localhost"),
  _team("Anonymous"),
  _port(4242),
  _ip("127.0.0.1"),
  _connected(false),
  _clientNum(-1),
  _sizeX(-1),
  _sizeY(-1),
  _fd(0),
  _direction(FRONT),
  _x(0),
  _y(0),
  _teamSize(1),
  _waitingTime(0),
  _ressourceOk(false),
  _level(1),
  _run(true)
{
  this->_xRun = this->_yRun = 0;
  this->_directionChecked[0] = this->_directionChecked[1] = this->_directionChecked[2] = this->_directionChecked[3] = false;
  this->_inventory = Ressource();
  this->argumentParsing(ac, av);
}

AiManager::~AiManager(void)
{
}

////////////////////////////////
///______PRIVATE METHODS_____///
////////////////////////////////

std::string   AiManager::getArg(int ac, char **av, int i, std::string find_me)
{
  if (std::string(av[i]) == find_me)
    {
      if (i + 1 < ac && (std::string(av[i + 1]).size() >= 1 && av[i + 1][0] != '-'))
        return (std::string(av[i + 1]));
      std::cerr << "Warning: missing argument for flag " << find_me << "." << std::endl;
    }
  return ("");
}

void          AiManager::findAndAttribute(int ac, char **av, int i)
{
  std::string tmp;

  if (std::string(av[i]).size() > 0 && av[i][0] == '-')
    {
      if ((tmp = getArg(ac, av, i, "-h")) != "")
        {
          this->_host = tmp;
          if (this->_host != "localhost")
            this->_ip = tmp;
          return ;
        }
      if ((tmp = getArg(ac, av, i, "-n")) != "")
        {
          this->_team = tmp;
          return ;
        }
      if ((tmp = getArg(ac, av, i, "-i")) != "")
        {
          this->_ip = tmp;
          return ;
        }
      if ((tmp = getArg(ac, av, i, "-p")) != "")
        {
          this->_port = std::stoi(tmp);
          return ;
        }
    }
}

void          AiManager::argumentParsing(int ac, char **av)
{
  for (int i = 0; i < ac; i++)
    findAndAttribute(ac, av, i);
}

////////////////////////////////
///______PUBLIC METHODS______///
////////////////////////////////

bool          AiManager::doConnect(void)
{
  std::vector<std::string>  tmp;

  this->_socket.sin_family = AF_INET;
  this->_socket.sin_port = htons(this->_port);
  this->_socket.sin_addr.s_addr = inet_addr(this->_ip.c_str());
  this->_fd = socket(AF_INET, SOCK_STREAM, 0);

  if (connect(this->_fd, reinterpret_cast<const struct sockaddr *>(&this->_socket), sizeof(this->_socket)) < 0)
    {
      std::cerr << "Socket connection: socket failed to connect" << std::endl;
      if (close(this->_fd) < 0)
        perror("Can't close socket after bad connection");
      return (false);
    }
  while (!this->_connected || this->_clientNum == -1 || this->_sizeX == -1 || this->_sizeY == -1)
    {
      this->readIn(this->_fd, &tmp);
      for (size_t i = 0; i < tmp.size(); i++)
        {
          if (tmp.at(i) == "ko")
            {
              std::cerr << "Identification: team " << this->_team << " is not registered on the server" << '\n';
              return (false);
            }
          if (tmp.at(i) == "WELCOME" && !this->_connected)
            {
              this->_connected = true;
              this->writeIn(this->_fd, this->_team + "\n");
            }
          else if (this->_clientNum == -1)
            this->_clientNum = std::stoi(tmp.at(i));
          else
            {
              if (tmp.at(i).find(" ") != std::string::npos)
                {
                  this->_sizeX = std::stoi(tmp.at(i).substr(0, tmp.at(i).find(" ")));
                  this->_sizeY = std::stoi(tmp.at(i).substr(tmp.at(i).find(" ") + 1));
                }
            }
        }
      tmp.clear();
    }
  tmp.clear();
  return (true);
}

bool          AiManager::doSelect(void)
{
  fd_set      fdRead;
  int         fdMax = 0;

  FD_ZERO(&fdRead);
  if (this->_fd > 0)
    {
      FD_SET(this->_fd, &fdRead);
      fdMax = this->_fd;
    }
  if (select(fdMax + 1, &fdRead, NULL, NULL, NULL) == -1)
    return (false);
  if (FD_ISSET(this->_fd, &fdRead))
    this->readIn(this->_fd, &this->_buffer);
  this->executeCommand();
  return (true);
}

////////////////////////////////
///____________TALK__________///
////////////////////////////////

void          AiManager::writeIn(int fd, std::string str)
{
  //std::cout << "#> " << str;
  write(fd, str.c_str(), str.size());
}

void          AiManager::readIn(int fd, std::vector<std::string> *dest)
{
  int         r;
  char        buf[8192];
  std::string ret;
  size_t      last;
  size_t      i;
  bool        go = true;
  std::string left;
  bool        canChange = false;

while (go)
  {
    canChange = false;
    r = read(fd, buf, 8192);
    go = false;
    if (r <= 0)
      return ;
    buf[r] = '\0';

    ret = left + std::string(buf);
    last = 0;
    for (i = 0; i < ret.size(); i++)
      {
        if (ret.substr(i, 1) == "\n")
          {
            if (epur(ret.substr(last, i - last)) != "")
              dest->push_back(epur(ret.substr(last, i - last)));
            last = i;
          }
      }
    if (ret.size() && ret.at(ret.size() - 1) != '\n')
      {
        go = true;
        left = ret.substr(last, i - last);
      }
    bzero(buf, 8192);

    for (size_t it = 0; it != this->_buffer.size(); it++)
      {
        if (std::strncmp("message", this->_buffer.at(it).c_str(), 7) == 0)
          {
            this->_message.push_back(this->_buffer.at(it));
            this->_buffer.erase(this->_buffer.begin() + it);
            canChange = true;
            it--;
          }
      }
    if (canChange == true && this->_buffer.size() == 0)
      go = true;
   }
}

////////////////////////////////
///___________GETTER_________///
////////////////////////////////

bool          AiManager::isRunning(void) const
{
  return (this->_run);
}

std::string   AiManager::getHost(void) const
{
  return (this->_host);
}

std::string   AiManager::getTeam(void) const
{
  return (this->_team);
}

int           AiManager::getPort(void) const
{
  return (this->_port);
}

char          **AiManager::getAv(void) const
{
  return (this->_av);
}

int           AiManager::getAc(void) const
{
  return (this->_ac);
}
