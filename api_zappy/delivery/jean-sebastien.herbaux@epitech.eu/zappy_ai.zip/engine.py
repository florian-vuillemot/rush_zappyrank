import zappy

class Engine:
    def __init__(self, port, name, host):
        self._zappy = zappy.Zappy(port, name, host)
        self._run = False
        self._error = None
        self._serverReply = ''
        self._aiReply = ''

    def getServerReply(self):
        self._serverReply = self._zappy._net.receive()
        return self._serverReply

    def init(self):
        self._zappy._net.connect() # Connect to the server
        print(self.getServerReply()) # Welcome message

        print('Retrieving player infos...')
        print("Player team: ", self._zappy._team)
        self._zappy._net.send(self._zappy._team + '\n') # Init call
        self.getServerReply() # Get reply

        rpls = self._serverReply.split('\n')
        if (rpls[0] == "ko"):
            print("Fatal error :(")
            exit(84)
        id_t = rpls[0]
        pos_t = rpls[1].split()

        self._zappy._player._id = int(rpls[0])
        self._zappy._player._position.x = int(pos_t[0])
        self._zappy._player._position.y = int(pos_t[1])

        print(id_t, pos_t)
        self._run = True
        # Call here for map && env initialisation

    def start(self):
        while self._run and not self._error:
            self.lap()

        if self._error:
            print(self._error)

    def lap(self):
        try: self._aiReply = input('$> ')
        except: self._error = 'Bad input or EOF'

        self._zappy._net.send(self._aiReply + '\n')
        print(self.getServerReply())

        self.compute()

    def compute(self):
        self._aiReply = 'Look'