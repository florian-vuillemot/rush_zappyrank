import net
import entities

class Env:
    def __init__(self):
        self._size = None
        self._map = []
    
    def generateMap(self, sizeX, sizeY):
        self._size = {'x': sizeX, 'y': sizeY}
        for y in range(sizeY):
            for x in range(sizeX):
                self._map[y][x] = entities.Cell(x, y)

    def addRessource(self, posX, posY, rtype, amount):
        if not self._size: return False
        for i in range(amount):
            self._map[posY][posX].addRessource(entities.Ressource(rtype, posX, posY))
        return True
    
    def dumpMap(self):
        if not self._size: return False
        for y in range(self._size['y']):
            for x in range(self._size['x']):
                self._map[y][x].dump()
        return True
                

class Zappy:
    def __init__(self, port, name, host):
        # Initialisation for parameters
        self._port = port
        self._host = host
        self._net = net.Net(host, port)
        self._team = name
        self._player = entities.Player(name)
        self._env = Env()