
class Ressource:

    RMAX_ID = 0
    
    def __init__(self, rtype, posX, posY):
        self._id = self.RMAX_ID
        self.RMAX_ID += 1
        self._type = rtype
        self._pos = {'x': posX, 'y': posY}
    
    def dump(self):
        print('|> ENTITY\t(' + str(self._id) + ')\t(' + self._type + ')\t(' + self._pos['y'] + ', ' + self._pos['x'] + ')')

class Cell:
    def __init__(self, posX, posY):
        self._ressources = []
        self._posX = posX
        self._posY = posY

    def addRessource(self, item):
        self._ressources.append(item)
    
    def dump(self):
        print('|> CELL\t(' + self._posY + ', ' + self._posX + ')')
        for r in self._ressources: r.dump()
        print('_' * 50)

class Position:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Player:
    def __init__(self, team):
        self._team = team
        self._level = 1
        self._inventory = []
        self._life = 1260
        self._id = None
        self._position = Position(0, 0)